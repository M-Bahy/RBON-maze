Coin 3d model
by
Brian K. Trepanier

03/05/05

http://trepaning.com

planar UVW mapping

36 verts
68 faces